import 'package:fluent_ui/fluent_ui.dart';
import '../../core/plugin/plugin_system.dart';

class VisualizationPlugin implements ISidePanel {
  @override
  String get id => 'vizualization'; // Unikal ID

  @override
  IconData get icon => FluentIcons.view_dashboard; // Ikonka

  @override
  String get title => 'Quantum Viz';

  @override
  String get tooltip => 'Visualization Dashboard';

  @override
  PanelPosition get position => PanelPosition.right; // <--- O'NG TOMONGA

  @override
  Widget buildContent(BuildContext context) {
    return Container(
      color: const Color(0xFF1E1E1E),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              FluentIcons.bar_chart_vertical,
              size: 50,
              color: const Color(0xFFE040FB),
            ),
            const SizedBox(height: 10),
            const Text("Bloch Sphere", style: TextStyle(color: Colors.white)),
            const SizedBox(height: 5),
            Container(width: 100, height: 2, color: Colors.green),
            const Padding(
              padding: EdgeInsets.all(20.0),
              child: Text(
                "Bu yerda kvant grafikalari chiziladi.\nHech narsa Explorerga bog'liq emas.",
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
