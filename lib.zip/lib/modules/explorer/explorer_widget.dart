import 'dart:io';
import 'package:fluent_ui/fluent_ui.dart';
import '../../core/services/file_service.dart';
import '../../core/services/editor_service.dart';
import '../../core/theme/ket_theme.dart';

class ExplorerWidget extends StatefulWidget {
  const ExplorerWidget({super.key});

  @override
  State<ExplorerWidget> createState() => _ExplorerWidgetState();
}

class _ExplorerWidgetState extends State<ExplorerWidget> {
  List<FileSystemEntity> _files = [];

  @override
  void initState() {
    super.initState();
    FileService().addListener(_refreshFiles);
    _refreshFiles();
  }

  @override
  void dispose() {
    FileService().removeListener(_refreshFiles);
    super.dispose();
  }

  void _refreshFiles() async {
    final files = FileService().getFiles(FileService().rootPath);
    if (mounted) {
      setState(() {
        _files = files;
      });
    }
  }

  void _onFileClick(FileSystemEntity entity) async {
    if (entity is File) {
      try {
        String content = await FileService().readFile(entity.path);
        String name = entity.path.split(Platform.pathSeparator).last;
        EditorService().openFile(name, content, realPath: entity.path);
      } catch (e) {
        debugPrint("Error opening file: $e");
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final rootPath = FileService().rootPath;
    return Column(
      children: [
        Container(
          height: 32,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          alignment: Alignment.centerLeft,
          color: KetTheme.bgActivityBar,
          child: Text(
            "EXPLORER: ${rootPath.split(Platform.pathSeparator).last.toUpperCase()}",
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.54),
              fontSize: 10,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: _files.length,
            itemBuilder: (context, index) {
              final entity = _files[index];
              final name = entity.path.split(Platform.pathSeparator).last;
              final isFile = entity is File;

              return HoverButton(
                onPressed: () => _onFileClick(entity),
                builder: (context, states) {
                  return Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 6,
                    ),
                    color: states.isHovered
                        ? Colors.white.withValues(alpha: 0.05)
                        : Colors.transparent,
                    child: Row(
                      children: [
                        Icon(
                          isFile
                              ? FluentIcons.page_list
                              : FluentIcons.folder_horizontal,
                          color: isFile
                              ? const Color(0xFF599E5E)
                              : const Color(0xFFDCB67A),
                          size: 14,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            name,
                            style: const TextStyle(
                              color: KetTheme.textMain,
                              fontSize: 12,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}
