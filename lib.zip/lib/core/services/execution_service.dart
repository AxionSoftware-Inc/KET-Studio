import 'dart:io';
import 'dart:convert';
import 'package:flutter/foundation.dart'; // <--- ValueNotifier uchun kerak
import 'terminal_service.dart';

class ExecutionService {
  static final ExecutionService _instance = ExecutionService._internal();
  factory ExecutionService() => _instance;
  ExecutionService._internal();

  Process? _process;

  // --- 1. BU YERDA XATO BERAYOTGAN "isRunning" BOR ---
  final ValueNotifier<bool> isRunning = ValueNotifier(false);

  Future<void> runPython(String filePath) async {
    final terminal = TerminalService();

    if (_process != null) stop();

    terminal.write("> python $filePath");
    terminal.write("----------------------------------------");

    try {
      isRunning.value = true; // <--- Ishga tushdi

      _process = await Process.start('python', ['-u', filePath]);

      if (_process == null) {
        terminal.write("❌ Error: Python start failed.");
        isRunning.value = false;
        return;
      }

      _process!.stdout.transform(utf8.decoder).listen(
            (data) {
          final lines = data.split('\n');
          for (var line in lines) {
            if (line.isNotEmpty) terminal.write(line);
          }
        },
      );

      _process!.stderr.transform(utf8.decoder).listen(
            (data) => terminal.write("Error: $data"),
      );

      int exitCode = await _process!.exitCode;

      terminal.write("----------------------------------------");
      terminal.write("Process finished with exit code $exitCode");

      _process = null;
      isRunning.value = false; // <--- To'xtadi

    } catch (e) {
      terminal.write("System Error: $e");
      isRunning.value = false;
    }
  }

  // --- 2. BU YERDA XATO BERAYOTGAN "writeToStdin" BOR ---
  void writeToStdin(String text) {
    if (_process != null) {
      try {
        _process!.stdin.writeln(text);
      } catch (e) {
        TerminalService().write("⚠️ Input Error: $e");
      }
    } else {
      TerminalService().write("⚠️ Hozir hech qanday dastur ishlamayapti.");
    }
  }

  void stop() {
    if (_process != null) {
      _process!.kill();
      TerminalService().write("\n🛑 Dastur majburan to'xtatildi.");
      _process = null;
      isRunning.value = false;
    }
  }
}